"use client";
import {useMemo,useState} from "react";
import {AppNav,Header,PageFooter,ResetDemoButton,Stat,useFinoraState} from "../components/FinoraShell";
import {getUser} from "../lib/db";

export default function Lead(){
 const {state,commit}=useFinoraState();
 const [activeLead,setActiveLead]=useState("lead-1");
 const [tab,setTab]=useState<"pending"|"approved"|"denied">("pending");
 const [reason,setReason]=useState("");
 const [selected,setSelected]=useState<string|null>(null);
 const [fingerprintOpen,setFingerprintOpen]=useState<string|null>(null);
 const [outgoingOtp,setOutgoingOtp]=useState<Record<string,string>>({});
 const leadUser=getUser(state,activeLead);

 // A Project Lead is also the receiver when receiverId === activeLead.
 // Therefore the receiver-only OTP inbox and the receiver fingerprint checkpoint
 // live on this same Project Lead screen. The Lead does not approve until this
 // fingerprint checkpoint is completed.
 const incomingOtp=useMemo(()=>state.requests.filter(r=>r.receiverId===activeLead&&r.status==="awaiting-otp").sort((a,b)=>b.createdAt-a.createdAt),[state.requests,activeLead]);
 const receiverFingerprintQueue=useMemo(()=>state.requests.filter(r=>r.receiverId===activeLead&&r.status==="awaiting-receiver-fingerprint").sort((a,b)=>b.createdAt-a.createdAt),[state.requests,activeLead]);
 const outgoing=useMemo(()=>state.requests.filter(r=>r.senderId===activeLead).sort((a,b)=>b.createdAt-a.createdAt),[state.requests,activeLead]);
 const queue=state.requests.filter(r=>r.leadId===activeLead&&(tab==="pending"?(r.status==="pending"):r.status===tab)).sort((a,b)=>b.createdAt-a.createdAt);

 const verifyLeadSenderOtp=(id:string)=>{const request=state.requests.find(r=>r.id===id);if(!request||request.senderId!==activeLead||request.status!=="awaiting-otp")return;const entered=(outgoingOtp[id]||"").trim();if(entered.length!==6){alert("Enter the 6-digit OTP shared by the receiver through the external medium.");return;}if(entered!==request.otp){alert("Incorrect OTP. Obtain the OTP from the receiver through the external medium.");return;}commit(current=>({...current,requests:current.requests.map(r=>r.id===id?{...r,status:"awaiting-receiver-fingerprint",otpVerified:true}:r),events:[...current.events,{id:crypto.randomUUID(),text:`${leadUser?.name||"Project Lead"} verified the sender OTP • waiting for receiver fingerprint`,level:"success",createdAt:Date.now()}]}));setOutgoingOtp(v=>({...v,[id]:""}));};

 const completeReceiverFingerprint=(id:string)=>{
   const request=state.requests.find(r=>r.id===id);
   if(!request||request.receiverId!==activeLead||request.status!=="awaiting-receiver-fingerprint")return;
   commit(current=>({...current,
     requests:current.requests.map(r=>r.id===id?{...r,status:"pending",fingerprintVerified:true}:r),
     events:[...current.events,{id:crypto.randomUUID(),text:`${leadUser?.name||"Project Lead"} receiver fingerprint verified • request moved to approval queue`,level:"success",createdAt:Date.now()}]
   }));
   setFingerprintOpen(null);
 };

 const decide=(id:string,status:"approved"|"denied")=>{
   if(!reason.trim()){alert("Enter the approval/denial reason.");return;}
   const request=state.requests.find(r=>r.id===id);
   if(!request||request.leadId!==activeLead||request.status!=="pending"||!request.fingerprintVerified){
     alert("Receiver fingerprint verification must be completed before the Lead can decide.");
     return;
   }
   const decisionReason=reason.trim();
   commit(current=>({...current,requests:current.requests.map(r=>r.id===id?{...r,status,leadReason:decisionReason}:r),events:[...current.events,{id:crypto.randomUUID(),text:`${leadUser?.name} ${status}: ${decisionReason}`,level:status==="approved"?"success":"warning",createdAt:Date.now()}]}));
   setReason("");setSelected(null);
 };

 return <div className="app-page"><Header role={`PROJECT LEAD WORKSPACE • ${leadUser?.name||"Project Lead"}`}/><AppNav role="project-lead"/><main className="dashboard-page">
  <div className="page-heading"><div><div className="eyebrow green left">PROJECT LEAD GOVERNANCE</div><h1>{leadUser?.name} Approval Command Centre</h1><p>Project Lead = Receiver for requests addressed to this Lead. The Lead sees the private OTP, verifies the receiver fingerprint after the sender verifies the OTP, then makes the final approval decision.</p></div><a className="primary-button nav-cta" href={`/lead/chat?user=${activeLead}`}>Open Secure Chat →</a></div>

  <section className="simulation-strip"><div><div className="section-title">RECEIVER / APPROVER IDENTITY</div><b>Simulate Project Lead:</b><span className="subtle"> The selected Lead is both the receiver and final approver.</span></div><div className="identity-switch">{state.users.filter(u=>u.role==="project-lead").map(u=><button key={u.id} className={activeLead===u.id?"active":""} onClick={()=>{setActiveLead(u.id);setTab("pending");setSelected(null);setReason("");setFingerprintOpen(null)}}>{u.name}<small>{u.department}</small></button>)}</div></section>

  <div className="stat-row four"><Stat label="OTP Waiting" value={incomingOtp.length} tone="warning"/><Stat label="Fingerprint Required" value={receiverFingerprintQueue.length} tone="warning"/><Stat label="Pending Approval" value={state.requests.filter(r=>r.leadId===activeLead&&r.status==="pending").length} tone="warning"/><Stat label="Approved" value={state.requests.filter(r=>r.leadId===activeLead&&r.status==="approved").length} tone="green"/></div>

  <section className="wide-panel receiver-panel"><div className="section-title">MY OUTGOING REQUESTS • {leadUser?.name?.toUpperCase()} (SENDER)</div><p className="subtle">When Project Lead sends a protected request to an employee, the employee sees the OTP. The Lead enters that OTP here and never sees it inside FINORA.</p>{outgoing.map(r=>{const receiver=getUser(state,r.receiverId);return <div className="otp-card" key={r.id}><div className="otp-card-main"><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><span>{r.status.replaceAll("-"," ").toUpperCase()}</span></div><h3>{r.title}</h3><p>To <b>{receiver?.name}</b> • {r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p></div><div className="otp-entry">{r.status==="awaiting-otp"?<div className="sender-otp-box"><b>🔐 ENTER OTP</b><span>The receiver has the OTP. Obtain it through your external communication medium.</span><div className="otp-input-row"><input inputMode="numeric" maxLength={6} value={outgoingOtp[r.id]||""} onChange={e=>setOutgoingOtp(v=>({...v,[r.id]:e.target.value.replace(/\D/g,"")}))} placeholder="Enter 6-digit OTP"/><button className="primary-button" onClick={()=>verifyLeadSenderOtp(r.id)}>Verify OTP</button></div></div>:r.status==="awaiting-receiver-fingerprint"?<div className="warning-box">✓ OTP VERIFIED<br/><span>Waiting for {receiver?.name} to complete fingerprint verification.</span></div>:r.status==="pending"?<div className="warning-box">✓ RECEIVER FINGERPRINT VERIFIED<br/><span>Waiting for final approval decision.</span></div>:r.status==="approved"?<div className="success-box">✓ APPROVED<br/><span>Why: {r.leadReason}</span></div>:r.status==="denied"?<div className="danger-box">✕ DENIED<br/><span>Why: {r.leadReason}</span></div>:<div className="success-box">Request does not require OTP verification.</div>}</div></div>})}{!outgoing.length&&<div className="empty-state">No outgoing requests for {leadUser?.name}.</div>}</section>

  <section className="wide-panel receiver-panel"><div className="section-title">PRIVATE OTP INBOX • {leadUser?.name?.toUpperCase()} (RECEIVER ONLY)</div>
   {incomingOtp.map(r=>{const sender=getUser(state,r.senderId);return <div className="otp-card" key={r.id}><div className="otp-card-main"><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><span>OTP REQUIRED</span></div><h3>{r.title}</h3><p>From <b>{sender?.name}</b> → <b>{leadUser?.name}</b> • {r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p><small>This OTP is visible only to you because you are the receiver. Share it with the sender through the external medium.</small></div><div className="otp-entry"><div className="otp-notification"><span>🔐 RECEIVER-ONLY OTP</span><strong>{r.otp}</strong><small>The sender must type this OTP in their own verification field. Do not expose it on the sender screen.</small></div></div></div>})}
   {!incomingOtp.length&&<div className="empty-state">No OTP is waiting for {leadUser?.name}.</div>}
  </section>

  <section className="wide-panel receiver-panel"><div className="section-title">RECEIVER FINGERPRINT VERIFICATION • {leadUser?.name?.toUpperCase()}</div>
   <p className="subtle">After the sender successfully enters the OTP, the receiver/Project Lead must complete this biometric checkpoint here. This is a simulated scanner; no physical hardware is connected.</p>
   {receiverFingerprintQueue.map(r=>{const sender=getUser(state,r.senderId);return <div className="otp-card" key={r.id}><div className="otp-card-main"><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><span>FINGERPRINT REQUIRED</span></div><h3>{r.title}</h3><p>From <b>{sender?.name}</b> → <b>{leadUser?.name}</b> • {r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p><div className="warning-box">✓ SENDER OTP VERIFIED<br/><span>{leadUser?.name} is the receiver for this request. Complete the fingerprint check to unlock the approval decision.</span></div></div><div className="otp-entry"><button className="primary-button" onClick={()=>setFingerprintOpen(r.id)}>Verify {leadUser?.name} Fingerprint</button></div></div>})}
   {!receiverFingerprintQueue.length&&<div className="empty-state">No receiver fingerprint verification is waiting for {leadUser?.name}.</div>}
  </section>

  <section className="wide-panel"><div className="section-title">GOVERNANCE QUEUE • {leadUser?.name?.toUpperCase()}</div><div className="tabs">{(["pending","approved","denied"] as const).map(t=><button key={t} className={tab===t?"active":""} onClick={()=>setTab(t)}>{t.toUpperCase()}</button>)}</div><div className="request-grid">{queue.map(r=>{const sender=getUser(state,r.senderId);const receiver=getUser(state,r.receiverId);return <div className="approval-card" key={r.id}><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><b>{r.risk}% AI RISK</b></div><h3>{r.title}</h3><p>{r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p><div className="routing-line">From <b>{sender?.name}</b> → <b>{receiver?.name}</b> • OTP {r.otpVerified?"VERIFIED":"NOT VERIFIED"}</div>{r.fingerprintVerified&&<div className="fingerprint-mini">✓ RECEIVER FINGERPRINT VERIFIED</div>}{tab==="pending"&&r.status==="pending"&&<><textarea value={selected===r.id?reason:""} onChange={e=>{setSelected(r.id);setReason(e.target.value)}} placeholder="Why are you approving or denying this?"/><div className="two-buttons"><button className="approve" onClick={()=>decide(r.id,"approved")}>✓ Approve</button><button className="deny" onClick={()=>decide(r.id,"denied")}>✕ Deny</button></div></>}{tab!=="pending"&&r.leadReason&&<div className={tab==="approved"?"success-box":"danger-box"}>{tab==="approved"?"✓ APPROVED":"✕ DENIED"}<br/><span>Why: {r.leadReason}</span></div>}</div>})}{!queue.length&&<div className="empty-state">No items in {leadUser?.name}'s {tab} queue.</div>}</div></section>

  <div className="simulation-flow"><span>1. Sender fingerprint</span><b>→</b><span>2. OTP generated</span><b>→</b><span>3. Receiver/Lead sees OTP</span><b>→</b><span>4. Sender enters OTP</span><b>→</b><span>5. Receiver/Lead fingerprint</span><b>→</b><span>6. Lead approves/denies</span></div>
  <div className="workspace-note"><b>Important:</b> For a request where Project Lead A is the receiver, Project Lead A performs the receiver fingerprint verification on this page and then makes the final decision. There is no separate receiver identity.</div>
  <ResetDemoButton/>
 </main><PageFooter/>
 {fingerprintOpen&&<div className="chat-overlay"><div className="chat-overlay-card fingerprint-auth-card"><div className="section-title">RECEIVER BIOMETRIC AUTHORIZATION</div><div className="fingerprint-demo-icon">☝</div><div className="eyebrow green">FINGERPRINT SCANNER • DEMO INTERFACE</div><h2>Verify {leadUser?.name} Fingerprint</h2><p className="subtle">{leadUser?.name} is the receiver and approver for this request. This is a visual biometric scanner simulation only.</p><div className="fingerprint-scan-ring"><span>◉</span></div><div className="request-buttons"><button className="ghost-button" onClick={()=>setFingerprintOpen(null)}>Cancel</button><button className="ghost-button" onClick={()=>completeReceiverFingerprint(fingerprintOpen)}>Bypass Fingerprint (Demo)</button><button className="primary-button" onClick={()=>completeReceiverFingerprint(fingerprintOpen)}>Verify Fingerprint</button></div></div></div>}
 </div>;
}
