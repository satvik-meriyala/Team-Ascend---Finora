"use client";
import {useCallback,useEffect,useRef,useState} from "react";
import {CHANNEL_NAME,FinoraState,loadState,resetState,saveState} from "../lib/db";

type StateUpdate = FinoraState | ((current:FinoraState)=>FinoraState);

export function useFinoraState(){
  const [state,setState]=useState<FinoraState>(()=>loadState());
  const stateRef=useRef(state);
  stateRef.current=state;

  useEffect(()=>{
    const sync=(incoming?:FinoraState)=>{
      const next=incoming||loadState();
      stateRef.current=next;
      setState(next);
    };
    const onStorage=(e:StorageEvent)=>{if(e.key===null||e.key===localStorageKey())sync()};
    const onCustom=(e:Event)=>{const detail=(e as CustomEvent<FinoraState>).detail;if(detail)sync(detail);};
    window.addEventListener("storage",onStorage);
    window.addEventListener("finora-state-changed",onCustom);
    let c:BroadcastChannel|null=null;
    try{
      c=new BroadcastChannel(CHANNEL_NAME);
      c.onmessage=e=>{if(e.data?.type==="state"&&e.data.state)sync(e.data.state);};
    }catch{}
    // A small polling fallback makes the localhost simulation reliable even when
    // a browser does not deliver BroadcastChannel/storage events immediately.
    const timer=window.setInterval(()=>{
      try{
        const raw=localStorage.getItem(localStorageKey());
        if(raw){const parsed=JSON.parse(raw) as FinoraState; if(JSON.stringify(parsed)!==JSON.stringify(stateRef.current))sync(parsed);}
      }catch{}
    },400);
    return()=>{window.removeEventListener("storage",onStorage);window.removeEventListener("finora-state-changed",onCustom);window.clearInterval(timer);c?.close();};
  },[]);

  const commit=useCallback((update:StateUpdate)=>{
    const current=loadState();
    const next=typeof update==="function"?update(current):update;
    stateRef.current=next;
    setState(next);
    saveState(next);
  },[]);

  return {state,commit};
}

function localStorageKey(){return "finora-role-aware-state-v252-bidirectional";}

export function Header({role,secure=false}:{role?:string;secure?:boolean}){
  return <header className={`topbar ${secure?"secure-header":""}`}><div className="brand"><span className="brand-mark">◈</span> FINORA {role&&<span className="role-chip">{role}</span>}</div><div className="top-status"><span className="pulse-dot"/> SYSTEM OPERATIONAL</div></header>;
}
export function AppNav({role}:{role:"employee"|"project-lead"|"cfo"}){
  const workspace=role==="employee"?"/employee":role==="project-lead"?"/lead":"/cfo";
  const chat=role==="employee"?"/employee/chat":role==="project-lead"?"/lead/chat":"/cfo/chat";
  return <aside className="side-nav"><a className="nav-logo" href={workspace} title="FINORA workspace">F</a><a className="nav-chat" href={chat} title="Secure Chat">▰</a></aside>;
}
export function PageFooter(){return <footer className="footer">◈ End-to-End Encrypted • FINORA Security Architecture • Demonstration Environment</footer>;}
export function ResetDemoButton(){return <button className="ghost-button" onClick={()=>{resetState();setTimeout(()=>location.reload(),100);}}>↻ Reset Demo</button>;}
export function Stat({label,value,tone=""}:{label:string;value:string|number;tone?:string}){return <div className="stat"><div className="stat-label">{label}</div><div className={`stat-value ${tone}`}>{value}</div></div>;}
export function SecurityPill({secure}:{secure:boolean}){return <div className={`connection-pill ${secure?"secure":""}`}>{secure?"🔴 SECURE CONNECTION":"🟢 NON-SECURE CONNECTION"}</div>;}
export function riskLabel(score:number){return score>=85?"CRITICAL":score>=65?"HIGH":score>=40?"MEDIUM":"LOW";}
