# FINORA v2.5.1 — Receiver = Project Lead

This build keeps the existing FINORA architecture and fixes the receiver/Project Lead workflow.

## Exact transaction flow
1. Sender opens the protected transaction request.
2. Sender sees the simulated fingerprint interface first. `Verify Fingerprint` or `Bypass Fingerprint (Demo)` continues.
3. OTP is generated only after the sender fingerprint step. The sender does not see the OTP.
4. If the selected receiver is a Project Lead, that same Project Lead sees the OTP in `PROJECT LEAD > PRIVATE OTP INBOX`. The OTP is not shown on the sender screen.
5. Sender receives the OTP through the external medium and types it into the sender's `Enter Transaction OTP` field.
6. After the sender verifies the OTP, the same Project Lead/receiver gets a `RECEIVER FINGERPRINT VERIFICATION` section on the Project Lead page.
7. The Lead clicks `Verify Project Lead A Fingerprint` (or the active Lead's name) and gets the simulated fingerprint interface with `Verify Fingerprint` and `Bypass Fingerprint (Demo)`.
8. After receiver fingerprint verification, the request enters the Lead's pending approval queue.
9. The same Project Lead manually enters a comment and chooses Approve or Deny.
10. State updates remain real-time across tabs using localStorage + BroadcastChannel + polling fallback.

## Demo
The fresh state includes a transaction addressed directly to Project Lead A and waiting for receiver fingerprint verification, so the fingerprint button is visible immediately on `/lead`.

Receiver/Lead demo OTP: `482731` (shown only in the receiver/Lead OTP inbox).

## Run
```bash
npm install
npm run dev
```

Open the localhost URL printed by Next.js.

If an older FINORA tab is open, close it before starting the new demo. This build uses a new storage/channel namespace so the old v2.5 state does not mask the new seeded flow.


## V2.5.2 bidirectional test flow

This build explicitly supports protected transactions in both directions:
- Employee -> Project Lead: sender fingerprint -> receiver-only OTP -> sender enters OTP -> Project Lead receiver fingerprint -> approval/denial.
- Project Lead -> Employee: sender fingerprint -> employee sees receiver-only OTP -> Project Lead enters OTP -> employee receiver fingerprint -> Project Lead approval/denial.

For the reverse demo, reset the demo state if necessary. The seeded reverse transaction is **Project Lead A -> Nishka Settlement** and uses demo OTP **614829** in the employee receiver notification center only. Project Lead A enters that OTP from the external medium in **MY OUTGOING REQUESTS**. The employee then has a **Verify Nishka Fingerprint** action directly on the employee workspace.
