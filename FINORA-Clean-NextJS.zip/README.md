# FINORA — Clean Demo Build

This is a fresh Next.js prototype based on the FINORA specification. It intentionally does not depend on the previous project implementation.

## Run

1. Install Node.js 20+ if you do not already have it.
2. Open this folder in VS Code.
3. Open Terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open http://localhost:3000

## Demonstration

Open multiple browser tabs:

- `/employee` — sender/employee
- `/employee/receiver` — receiver OTP view
- `/lead` — Project Lead chat + approvals
- `/cfo` — CFO command centre + chat

The demo synchronizes state across tabs using `localStorage` and `BroadcastChannel`.

## Security flow

Normal message:
Employee → message → recipient.

High-risk transaction/confidential file:
Employee → AI risk classification → receiver OTP → Project Lead queue → reason + fingerprint release hook → Approved/Denied → employee/receiver status → CFO oversight.

The CFO sees Project Lead activity and does not receive the Project Lead approval queue.

## Biometric note

Project Lead login has a webcam + randomized blink/hold challenge UI. For reliable laptop demonstration, each displayed action is registered with a button because a raw webcam feed does not itself provide a biometric landmark model. The production hook is isolated in `BiometricFlow.tsx` and can be replaced by continuous MediaPipe landmark detection.

CFO iris verification is intentionally represented as a demo bypass because ordinary laptops do not provide an iris scanner.

Fingerprint is intentionally attached to confidential release/approval, not ordinary Project Lead login.
