 "use client";

import { useEffect, useRef, useState } from "react";

type Props = { onVerified: () => void };

export default function BiometricFlow({ onVerified }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [status, setStatus] = useState("Starting camera…");
  const [challenge, setChallenge] = useState<string[]>([]);
  const [progress, setProgress] = useState<string[]>([]);
  const [cameraReady, setCameraReady] = useState(false);
  const [error, setError] = useState("");
  const [simulated, setSimulated] = useState(false);

  useEffect(() => {
    const seq = Array.from({length: 3}, () => Math.random() > 0.5 ? "BLINK" : "HOLD");
    setChallenge(seq);
    let stream: MediaStream | null = null;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
        if (videoRef.current) videoRef.current.srcObject = stream;
        setCameraReady(true);
        setStatus("Camera active • align your face");
      } catch {
        setError("Camera permission was unavailable. You can use the demo verification below.");
        setStatus("Camera unavailable");
      }
    })();
    return () => stream?.getTracks().forEach(t => t.stop());
  }, []);

  const simulateBlink = () => {
    if (!cameraReady) return;
    const idx = progress.length;
    if (idx >= challenge.length) return;
    setProgress(p => [...p, challenge[idx]]);
    if (idx + 1 === challenge.length) {
      setStatus("Dynamic blink challenge passed");
      setTimeout(onVerified, 500);
    } else {
      setStatus(`Detected ${challenge[idx]} • perform the next action`);
    }
  };

  return (
    <div className="biometric-card">
      <div className="eyebrow green">BIOMETRIC AUTHENTICATION • ARMED</div>
      <h1>Facial + Eye Challenge</h1>
      <p className="center-copy">Use the webcam to perform a randomly generated eye challenge. The sequence changes every session.</p>
      <div className="camera-box">
        {cameraReady ? <video ref={videoRef} autoPlay muted playsInline /> : <div className="camera-placeholder">◉</div>}
        <div className="reticle">◎</div>
        <div className="camera-status">{status}</div>
      </div>
      <div className="challenge-row">
        {challenge.map((c,i) => <div key={i} className={`challenge ${progress[i] ? "done" : ""}`}>{i+1}. {c}</div>)}
      </div>
      <div className="subtle center-copy">For this laptop demo, press the control when you physically perform each displayed action. Production can replace this hook with continuous landmark-based blink detection.</div>
      <button className="primary-button wide" disabled={!cameraReady || simulated} onClick={simulateBlink}>
        {progress.length < challenge.length ? `Register ${challenge[progress.length]}` : "Challenge Passed"}
      </button>
      <button className="ghost-button wide" onClick={() => { setSimulated(true); setStatus("Demo biometric verification passed"); setTimeout(onVerified, 400); }}>
        Bypass / Demo Verification
      </button>
      {error && <div className="warning-box">{error}</div>}
    </div>
  );
}
