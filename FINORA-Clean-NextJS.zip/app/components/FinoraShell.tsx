"use client";

import { useEffect, useMemo, useState } from "react";
import { CHANNEL_NAME, FinoraState, loadState, resetState, saveState } from "../lib/db";

export function useFinoraState() {
  const [state, setState] = useState<FinoraState>(() => loadState());

  useEffect(() => {
    const sync = () => setState(loadState());
    window.addEventListener("storage", sync);
    let channel: BroadcastChannel | null = null;
    try {
      channel = new BroadcastChannel(CHANNEL_NAME);
      channel.onmessage = (e) => {
        if (e.data?.type === "state") setState(e.data.state);
      };
    } catch {}
    return () => {
      window.removeEventListener("storage", sync);
      channel?.close();
    };
  }, []);

  const commit = (next: FinoraState) => {
    setState(next);
    saveState(next);
  };

  return { state, commit };
}

export function Header({ role, secure = false }: { role?: string; secure?: boolean }) {
  return (
    <header className={`topbar ${secure ? "secure-frame" : ""}`}>
      <div className="brand">
        <span className="brand-mark">◈</span>
        <span>FINORA</span>
        {role && <span className="role-chip">{role}</span>}
      </div>
      <div className="top-status">
        <span className="pulse-dot" />
        SYSTEM OPERATIONAL
      </div>
    </header>
  );
}

export function SecurityPill({ secure }: { secure: boolean }) {
  return (
    <div className={`connection-pill ${secure ? "secure" : ""}`}>
      <span>{secure ? "🔴" : "🟢"}</span>
      {secure ? "SECURE CONNECTION" : "NON-SECURE CONNECTION"}
    </div>
  );
}

export function AppNav({ role }: { role: string }) {
  return (
    <aside className="side-nav">
      <div className="nav-logo">F</div>
      <a href={role === "employee" ? "/employee" : role === "project-lead" ? "/lead" : "/cfo"}>▣</a>
      <a href="/">⌂</a>
      <a href={role === "employee" ? "/employee/receiver" : role === "project-lead" ? "/lead" : "/cfo"}>◫</a>
      <a href="/">⚙</a>
    </aside>
  );
}

export function PageFooter() {
  return <footer className="footer">◈ End-to-End Encrypted • FINORA Security Architecture • Demo Environment</footer>;
}

export function ResetDemoButton() {
  const [done, setDone] = useState(false);
  return (
    <button className="ghost-button" onClick={() => { resetState(); setDone(true); setTimeout(() => location.reload(), 150); }}>
      ↻ {done ? "RESETTING…" : "Reset Demo"}
    </button>
  );
}

export function Stat({ label, value, tone = "" }: { label: string; value: string | number; tone?: string }) {
  return <div className="stat"><div className="stat-label">{label}</div><div className={`stat-value ${tone}`}>{value}</div></div>;
}

export function riskLabel(score: number) {
  return score >= 85 ? "CRITICAL" : score >= 65 ? "HIGH" : score >= 40 ? "MEDIUM" : "LOW";
}
