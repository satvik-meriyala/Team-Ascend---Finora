"use client";

import { useMemo, useState } from "react";
import { FinoraState, Message, SecurityRequest, getUser, needsVerification, riskScore, sensitivityFromRisk } from "../lib/db";
import { SecurityPill, useFinoraState } from "./FinoraShell";

type Props = {
  currentUserId: string;
  otherUserId: string;
  title?: string;
  onRequestCreated?: (request: SecurityRequest) => void;
};

export default function ChatWindow({ currentUserId, otherUserId, title, onRequestCreated }: Props) {
  const { state, commit } = useFinoraState();
  const [text, setText] = useState("");
  const [secure, setSecure] = useState(false);
  const [mode, setMode] = useState<"message" | "transaction" | "file">("message");
  const [amount, setAmount] = useState("50000");
  const [fileName, setFileName] = useState("Confidential_Project_Report.pdf");

  const other = getUser(state, otherUserId);
  const messages = useMemo(
    () => state.messages.filter(m => (m.from === currentUserId && m.to === otherUserId) || (m.from === otherUserId && m.to === currentUserId)).sort((a,b) => a.createdAt-b.createdAt),
    [state.messages, currentUserId, otherUserId]
  );

  const sendMessage = () => {
    if (!text.trim()) return;
    const next = { ...state, messages: [...state.messages, { id: crypto.randomUUID(), from: currentUserId, to: otherUserId, text: text.trim(), createdAt: Date.now(), secure }] };
    next.events = [...next.events, { id: crypto.randomUUID(), text: `${getUser(state,currentUserId)?.name} sent a ${secure ? "secure" : "normal"} message`, level: secure ? "warning" : "info", createdAt: Date.now() }];
    commit(next); setText("");
  };

  const createRequest = () => {
    const numericAmount = Number(amount) || 0;
    const risk = riskScore(mode === "transaction" ? "transaction" : "file", numericAmount, fileName);
    const sensitivity = sensitivityFromRisk(risk);
    const requires = needsVerification({ sensitivity, amount: numericAmount });
    const request: SecurityRequest = {
      id: crypto.randomUUID(),
      kind: mode,
      senderId: currentUserId,
      receiverId: otherUserId,
      leadId: "lead-1",
      title: mode === "transaction" ? "Transaction Request" : fileName,
      amount: mode === "transaction" ? numericAmount : undefined,
      fileName: mode === "file" ? fileName : undefined,
      sensitivity,
      risk,
      status: requires ? "awaiting-otp" : "normal",
      createdAt: Date.now(),
      otp: requires ? String(Math.floor(100000 + Math.random() * 900000)) : undefined
    };
    const next = { ...state, requests: [...state.requests, request], events: [...state.events, {
      id: crypto.randomUUID(),
      text: `${request.kind === "transaction" ? "Transaction" : "File"} analyzed: ${risk}% risk (${sensitivity})`,
      level: risk >= 65 ? "warning" : "success",
      createdAt: Date.now()
    }]};
    commit(next);
    onRequestCreated?.(request);
    setMode("message");
    alert(requires ? `Receiver verification required. Demo OTP: ${request.otp}` : "Action cleared by the AI risk engine.");
  };

  return (
    <section className={`chat-panel ${secure ? "secure-chat" : ""}`}>
      <div className="chat-head">
        <div>
          <div className="eyebrow">VERIFIED CHANNEL</div>
          <h2>{title || other?.name || "Secure Contact"}</h2>
          <span className="subtle">{other?.department} • {other?.online ? "Active now" : "Offline"}</span>
        </div>
        <div className="chat-actions">
          <button className="icon-button" title="Voice call">☎</button>
          <button className="icon-button" title="Video call">▣</button>
          <button className="icon-button" title="Search">⌕</button>
        </div>
      </div>

      <div className="chat-security">
        <SecurityPill secure={secure} />
        <button className={`toggle-button ${secure ? "on" : ""}`} onClick={() => setSecure(!secure)}>
          {secure ? "Disable Secure Mode" : "Enable Secure Mode"}
        </button>
      </div>

      <div className="message-list">
        <div className="encryption-banner">🔒 Session protected • {secure ? "secure tunnel active" : "standard channel"}</div>
        {messages.map(m => (
          <div key={m.id} className={`message-row ${m.from === currentUserId ? "mine" : ""}`}>
            <div className="message-bubble">
              {m.secure && <span className="tiny-secure">🔴 SECURE</span>}
              <div>{m.text}</div>
              <small>{new Date(m.createdAt).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})}</small>
            </div>
          </div>
        ))}
      </div>

      <div className="composer">
        <div className="compose-tools">
          <button className={mode === "message" ? "active" : ""} onClick={() => setMode("message")}>💬</button>
          <button className={mode === "file" ? "active" : ""} onClick={() => setMode("file")}>📎</button>
          <button title="Voice note">🎙</button>
          <button title="Emoji">☺</button>
          <button className={mode === "transaction" ? "active" : ""} onClick={() => setMode("transaction")}>₹</button>
        </div>

        {mode === "message" ? (
          <div className="compose-line">
            <input value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === "Enter" && sendMessage()} placeholder={`Message ${other?.name || "contact"}…`} />
            <button className="send-button" onClick={sendMessage}>Send ➤</button>
          </div>
        ) : (
          <div className="request-box">
            <div className="request-title">{mode === "transaction" ? "₹ Secure Transaction" : "📎 Secure File Share"}</div>
            {mode === "transaction" ? (
              <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" />
            ) : (
              <input value={fileName} onChange={e => setFileName(e.target.value)} placeholder="File name" />
            )}
            <div className="risk-note">AI will classify sensitivity and route high-risk actions through receiver OTP + Project Lead approval.</div>
            <div className="request-buttons">
              <button className="ghost-button" onClick={() => setMode("message")}>Cancel</button>
              <button className="primary-button" onClick={createRequest}>Analyze & Send</button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
