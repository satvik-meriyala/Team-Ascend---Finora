export type Role = "employee" | "project-lead" | "cfo";
export type RequestKind = "transaction" | "file";
export type RequestStatus = "normal" | "awaiting-otp" | "pending" | "approved" | "denied";

export type User = {
  id: string;
  name: string;
  role: Role;
  department: string;
  online: boolean;
  leadId?: string;
};

export type Message = {
  id: string;
  from: string;
  to: string;
  text: string;
  createdAt: number;
  secure: boolean;
};

export type SecurityRequest = {
  id: string;
  kind: RequestKind;
  senderId: string;
  receiverId: string;
  leadId: string;
  title: string;
  amount?: number;
  fileName?: string;
  sensitivity: "low" | "medium" | "high" | "critical";
  risk: number;
  status: RequestStatus;
  otp?: string;
  otpVerified?: boolean;
  fingerprintVerified?: boolean;
  leadReason?: string;
  createdAt: number;
};

export type SecurityEvent = {
  id: string;
  text: string;
  level: "info" | "success" | "warning" | "critical";
  createdAt: number;
};

export type FinoraState = {
  users: User[];
  messages: Message[];
  requests: SecurityRequest[];
  events: SecurityEvent[];
};

export const STORAGE_KEY = "finora-demo-state-v1";
export const CHANNEL_NAME = "finora-demo-sync";

export const seedState: FinoraState = {
  users: [
    { id: "emp-1", name: "Nishka", role: "employee", department: "Operations", online: true },
    { id: "emp-2", name: "Arjun", role: "employee", department: "Finance", online: true },
    { id: "lead-1", name: "Project Lead A", role: "project-lead", department: "Project Core Mesh", online: true },
    { id: "lead-2", name: "Project Lead B", role: "project-lead", department: "Secure Infrastructure", online: true },
    { id: "cfo-1", name: "CFO", role: "cfo", department: "Executive", online: true }
  ],
  messages: [
    { id: "m1", from: "lead-1", to: "emp-1", text: "Please review the updated vendor request. I will verify any high-risk action here.", createdAt: Date.now() - 1000 * 60 * 18, secure: false },
    { id: "m2", from: "emp-1", to: "lead-1", text: "Received. I will send the invoice through the secure channel.", createdAt: Date.now() - 1000 * 60 * 16, secure: false },
    { id: "m3", from: "cfo-1", to: "lead-1", text: "Please keep the approval rationale attached to every sensitive decision.", createdAt: Date.now() - 1000 * 60 * 12, secure: true }
  ],
  requests: [
    {
      id: "req-demo",
      kind: "transaction",
      senderId: "emp-1",
      receiverId: "lead-1",
      leadId: "lead-1",
      title: "Invoice Settlement — ABC Solutions",
      amount: 50000,
      sensitivity: "high",
      risk: 72,
      status: "pending",
      createdAt: Date.now() - 1000 * 60 * 5
    }
  ],
  events: [
    { id: "e1", text: "Secure messaging mesh initialized", level: "success", createdAt: Date.now() - 1000 * 60 * 10 },
    { id: "e2", text: "AI risk engine ready for transaction analysis", level: "info", createdAt: Date.now() - 1000 * 60 * 8 }
  ]
};

export function loadState(): FinoraState {
  if (typeof window === "undefined") return seedState;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(seedState));
      return seedState;
    }
    return JSON.parse(raw) as FinoraState;
  } catch {
    return seedState;
  }
}

export function saveState(state: FinoraState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  try {
    const channel = new BroadcastChannel(CHANNEL_NAME);
    channel.postMessage({ type: "state", state });
    channel.close();
  } catch {}
}

export function resetState() {
  saveState(seedState);
}

export function getUser(state: FinoraState, id: string) {
  return state.users.find((u) => u.id === id);
}

export function riskScore(kind: RequestKind, amount: number, fileName: string) {
  let score = kind === "transaction" ? 30 : 20;
  if (amount >= 10000) score += 25;
  if (amount >= 50000) score += 15;
  if (/confidential|secret|contract|payroll|credentials|ledger/i.test(fileName)) score += 25;
  return Math.min(98, score + Math.floor(Math.random() * 8));
}

export function sensitivityFromRisk(risk: number): SecurityRequest["sensitivity"] {
  if (risk >= 85) return "critical";
  if (risk >= 65) return "high";
  if (risk >= 40) return "medium";
  return "low";
}

export function needsVerification(r: Pick<SecurityRequest, "sensitivity" | "amount">) {
  return r.sensitivity === "high" || r.sensitivity === "critical" || (r.amount ?? 0) >= 25000;
}
