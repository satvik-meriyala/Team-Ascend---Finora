"use client";
import { useMemo, useState } from "react";
import ChatWindow from "../components/ChatWindow";
import { AppNav, Header, PageFooter, ResetDemoButton, Stat, useFinoraState } from "../components/FinoraShell";
import { getUser } from "../lib/db";

export default function LeadPage() {
  const {state,commit}=useFinoraState();
  const [tab,setTab]=useState<"pending"|"approved"|"denied">("pending");
  const [contact,setContact]=useState("emp-1");
  const [reason,setReason]=useState("");
  const [selected,setSelected]=useState<string|null>(null);
  const queue=state.requests.filter(r=>r.leadId==="lead-1" && r.status===tab);
  const decide=(id:string,decision:"approved"|"denied")=>{
    if(!reason.trim()){alert("Enter a reason before deciding.");return;}
    const next={...state,requests:state.requests.map(r=>r.id===id?{...r,status:decision,leadReason:reason,fingerprintVerified:true}:r),events:[...state.events,{id:crypto.randomUUID(),text:`Project Lead ${decision} request: ${reason}`,level:decision==="approved"?"success":"warning",createdAt:Date.now()}]};
    commit(next);setReason("");setSelected(null);
  };
  return <div className="app-page"><Header role="PROJECT LEAD"/><AppNav role="project-lead"/><main className="workspace lead-workspace">
    <aside className="contacts"><div className="section-title">LEAD CHAT</div>{state.users.filter(u=>u.id!=="lead-1").map(u=><button key={u.id} className={`contact ${contact===u.id?"selected":""}`} onClick={()=>setContact(u.id)}><span className="avatar">{u.name[0]}</span><span><strong>{u.name}</strong><small>{u.department}</small></span><i className="online"/></button>)}</aside>
    <section className="main-chat"><ChatWindow currentUserId="lead-1" otherUserId={contact}/></section>
    <aside className="approval-panel"><div className="page-heading compact"><div><div className="eyebrow green">GOVERNANCE QUEUE</div><h2>Approvals</h2></div></div>
      <div className="stat-row"><Stat label="Pending" value={state.requests.filter(r=>r.leadId==="lead-1"&&r.status==="pending").length}/><Stat label="Approved" value={state.requests.filter(r=>r.leadId==="lead-1"&&r.status==="approved").length} tone="green"/><Stat label="Denied" value={state.requests.filter(r=>r.leadId==="lead-1"&&r.status==="denied").length} tone="red"/></div>
      <div className="tabs">{(["pending","approved","denied"] as const).map(t=><button className={tab===t?"active":""} onClick={()=>setTab(t)} key={t}>{t.toUpperCase()}</button>)}</div>
      <div className="approval-list">{queue.map(r=><div className="approval-card" key={r.id}><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><b>{r.risk}% risk</b></div><h3>{r.title}</h3><p>{r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p><div className="approval-meta">Receiver: {getUser(state,r.receiverId)?.name}<br/>AI classification: {r.sensitivity}</div>{tab==="pending"&&<><div className="fingerprint-mini">◉ Fingerprint required for confidential release</div><textarea value={selected===r.id?reason:""} onChange={e=>{setSelected(r.id);setReason(e.target.value)}} placeholder="Why are you approving or denying this?"/><div className="two-buttons"><button className="approve" onClick={()=>decide(r.id,"approved")}>✓ Approve</button><button className="deny" onClick={()=>decide(r.id,"denied")}>✕ Deny</button></div></>}{tab!=="pending"&&<div className={tab==="approved"?"success-box":"danger-box"}>{tab==="approved"?"✓ Approved":"✕ Denied"} — {r.leadReason}</div>}</div>)}</div>
      <ResetDemoButton/>
    </aside>
  </main><PageFooter/></div>;
}
