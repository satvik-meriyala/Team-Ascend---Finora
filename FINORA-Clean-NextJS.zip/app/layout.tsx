import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "FINORA — Secure Communication",
  description: "AI-assisted deepfake and transaction security demonstration platform"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
