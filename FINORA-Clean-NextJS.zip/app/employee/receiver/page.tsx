"use client";
import { useMemo, useState } from "react";
import { AppNav, Header, PageFooter, useFinoraState, Stat } from "../../components/FinoraShell";
import { getUser } from "../../lib/db";

export default function ReceiverPage() {
  const {state,commit}=useFinoraState();
  const [selected,setSelected]=useState<string|null>(null);
  const [otp,setOtp]=useState("");
  const incoming=useMemo(()=>state.requests.filter(r=>r.receiverId==="lead-1" || r.receiverId==="emp-2" || r.receiverId==="emp-1"),[state.requests]);
  const verify=(id:string)=>{
    const req=state.requests.find(r=>r.id===id); if(!req) return;
    if(req.otp && otp!==req.otp){alert("Incorrect demo OTP. Use the OTP displayed when the request was created.");return;}
    const next={...state,requests:state.requests.map(r=>r.id===id?{...r,otpVerified:true,status:"pending"}:r),events:[...state.events,{id:crypto.randomUUID(),text:"Receiver OTP verified; request routed to Project Lead",level:"success",createdAt:Date.now()}]};
    commit(next); setSelected(null); setOtp("");
  };
  return <div className="app-page"><Header role="RECEIVER VIEW"/><AppNav role="employee"/><main className="workspace receiver-layout">
    <section className="dashboard-main"><div className="page-heading"><div><div className="eyebrow green">RECEIVER SECURITY GATE</div><h1>Incoming Protected Actions</h1><p>Use this view as the receiving user during the live demonstration.</p></div><Stat label="Awaiting OTP" value={incoming.filter(r=>r.status==="awaiting-otp").length}/></div>
      <div className="request-grid">{incoming.map(r=><div className={`request-card ${r.status}`} key={r.id}><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><span>{r.status}</span></div><h3>{r.title}</h3><p>{r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p><div className="risk-bar"><span style={{width:`${r.risk}%`}}/></div><small>AI risk score {r.risk}% • Sender {getUser(state,r.senderId)?.name}</small>{r.status==="awaiting-otp"&&<button className="primary-button wide" onClick={()=>setSelected(r.id)}>Verify Receiver OTP</button>}{r.status==="pending"&&<div className="success-box">✓ Receiver verified • Waiting for Project Lead</div>}{r.status==="approved"&&<div className="success-box">✓ Approved and released</div>}{r.status==="denied"&&<div className="danger-box">✕ Denied by Project Lead</div>}</div>)}</div>
    </section>
  </main>{selected&&<div className="modal-backdrop"><div className="modal"><div className="eyebrow red">● SECURE ACTION</div><h2>Receiver Verification</h2><p>Enter the six-digit OTP delivered to the receiver. In this prototype, the OTP is shown in the creation alert.</p><input className="otp-input" maxLength={6} value={otp} onChange={e=>setOtp(e.target.value)} placeholder="• • • • • •"/><button className="primary-button wide" onClick={()=>verify(selected)}>Verify & Continue</button><button className="ghost-button wide" onClick={()=>setSelected(null)}>Cancel</button></div></div>}<PageFooter/></div>;
}
