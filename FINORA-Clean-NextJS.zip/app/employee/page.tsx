"use client";
import { useMemo, useState } from "react";
import ChatWindow from "../components/ChatWindow";
import { AppNav, Header, PageFooter, ResetDemoButton, useFinoraState, Stat } from "../components/FinoraShell";
import { getUser } from "../lib/db";

export default function EmployeePage() {
  const {state}=useFinoraState();
  const [contact,setContact]=useState("lead-1");
  const [notice,setNotice]=useState("");
  const me=getUser(state,"emp-1")!;
  const contacts=state.users.filter(u=>u.id!=="emp-1");
  const myRequests=state.requests.filter(r=>r.senderId==="emp-1");
  return <div className="app-page"><Header role="EMPLOYEE"/><AppNav role="employee"/><main className="workspace">
    <aside className="contacts">
      <div className="section-title">CHATS <span>{contacts.length} Active</span></div>
      <input className="search" placeholder="⌕ Search channels, contracts, hashes…"/>
      {contacts.map(u=><button key={u.id} className={`contact ${contact===u.id?"selected":""}`} onClick={()=>setContact(u.id)}><span className="avatar">{u.name[0]}</span><span><strong>{u.name}</strong><small>{u.department}</small></span><i className="online"/></button>)}
      <div className="mini-status"><span className="pulse-dot"/> Zero-Knowledge Sync Connected</div>
    </aside>
    <section className="main-chat"><ChatWindow currentUserId="emp-1" otherUserId={contact} onRequestCreated={()=>setNotice("Request created. Open Receiver View to continue the demo.")}/></section>
    <aside className="right-panel">
      <div className="section-title">MY SECURITY QUEUE</div>
      <Stat label="Pending verification" value={myRequests.filter(r=>r.status==="awaiting-otp"||r.status==="pending").length} tone="warning"/>
      <Stat label="Approved" value={myRequests.filter(r=>r.status==="approved").length} tone="green"/>
      <Stat label="Denied" value={myRequests.filter(r=>r.status==="denied").length} tone="red"/>
      {notice&&<div className="success-box">{notice}</div>}
      <div className="tip-card"><b>Demo flow</b><p>Send a high-value transaction or confidential file → open Receiver View → verify OTP → Project Lead approves/denies → return here.</p></div>
      <ResetDemoButton/>
    </aside>
  </main><PageFooter/></div>;
}
