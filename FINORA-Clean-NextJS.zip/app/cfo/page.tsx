"use client";
import { useMemo, useState } from "react";
import ChatWindow from "../components/ChatWindow";
import { AppNav, Header, PageFooter, ResetDemoButton, Stat, useFinoraState } from "../components/FinoraShell";
import { getUser } from "../lib/db";

export default function CfoPage() {
  const {state}=useFinoraState();
  const [lead,setLead]=useState("lead-1");
  const [contact,setContact]=useState("lead-1");
  const leads=state.users.filter(u=>u.role==="project-lead");
  const activity=state.requests.filter(r=>r.leadId===lead).sort((a,b)=>b.createdAt-a.createdAt);
  const leadUser=getUser(state,lead);
  return <div className="app-page"><Header role="CFO COMMAND CENTRE"/><AppNav role="cfo"/><main className="workspace cfo-workspace">
    <aside className="contacts"><div className="section-title">PROJECT LEADS <span>{leads.length}</span></div>{leads.map(u=><button key={u.id} className={`contact ${lead===u.id?"selected":""}`} onClick={()=>setLead(u.id)}><span className="avatar">{u.name.slice(-1)}</span><span><strong>{u.name}</strong><small>{u.department}</small></span><i className="online"/></button>)}<div className="tip-card"><b>Executive view</b><p>The CFO observes what each Project Lead is approving, denying and currently reviewing. No direct transaction approval queue.</p></div></aside>
    <section className="cfo-center">
      <div className="page-heading"><div><div className="eyebrow green">EXECUTIVE OVERSIGHT</div><h1>{leadUser?.name} Activity</h1><p>Live governance telemetry for the selected Project Lead.</p></div><div className="cfo-iris">◉ IRIS VERIFY • DEMO BYPASS</div></div>
      <div className="stat-row"><Stat label="Total actions" value={activity.length}/><Stat label="Approved" value={activity.filter(r=>r.status==="approved").length} tone="green"/><Stat label="Denied" value={activity.filter(r=>r.status==="denied").length} tone="red"/><Stat label="Pending" value={activity.filter(r=>r.status==="pending").length} tone="warning"/></div>
      <div className="activity-list">{activity.length?activity.map(r=><div className="activity-row" key={r.id}><div className="activity-time">{new Date(r.createdAt).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</div><div className="activity-icon">{r.status==="approved"?"✓":r.status==="denied"?"✕":"…"}</div><div><strong>{r.status.toUpperCase()} — {r.title}</strong><p>{r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName} • AI risk {r.risk}%</p>{r.leadReason&&<small>Reason: {r.leadReason}</small>}</div></div>):<div className="empty-state">No actions recorded for this lead yet.</div>}</div>
    </section>
    <section className="cfo-chat"><div className="section-title">CFO CHAT</div><div className="lead-chat-picker">{leads.map(u=><button key={u.id} className={contact===u.id?"active":""} onClick={()=>setContact(u.id)}>{u.name}</button>)}</div><ChatWindow currentUserId="cfo-1" otherUserId={contact} title={`Chat with ${getUser(state,contact)?.name || "Project Lead"}`}/></section>
  </main><PageFooter/></div>;
}
