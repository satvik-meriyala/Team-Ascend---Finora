import Link from "next/link";
import { PageFooter } from "./components/FinoraShell";

export default function Home() {
  const roles = [
    { href: "/login/employee", name: "Employee", icon: "▣", desc: "Secure messaging, files and transactions" },
    { href: "/login/project-lead", name: "Project Lead", icon: "✥", desc: "Biometric access and approval governance" },
    { href: "/login/cfo", name: "CFO", icon: "₿", desc: "Executive oversight and lead activity analytics" }
  ];
  return (
    <main className="auth-page">
      <header className="topbar"><div className="brand"><span className="brand-mark">◈</span><span>FINORA</span></div><div className="top-status"><span className="pulse-dot"/> SYSTEM OPERATIONAL</div></header>
      <div className="role-center">
        <div className="login-card">
          <div className="eyebrow green">● LOGIN</div>
          <h1>Select Your Role</h1>
          <p className="subtle center-copy">Choose the workspace used for this security demonstration.</p>
          <div className="role-list">
            {roles.map(r => <Link className="role-option" href={r.href} key={r.name}><span className="role-icon">{r.icon}</span><span><strong>{r.name}</strong><small>{r.desc}</small></span><span className="arrow">→</span></Link>)}
          </div>
        </div>
      </div>
      <PageFooter />
    </main>
  );
}
