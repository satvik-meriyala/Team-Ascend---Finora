"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import BiometricFlow from "../../components/BiometricFlow";

export default function ProjectLeadLogin() {
  const router = useRouter();
  const [stage,setStage]=useState<"credentials"|"biometric"|"fingerprint">("credentials");
  if(stage==="biometric") return <main className="auth-page"><header className="topbar"><div className="brand">◈ FINORA</div><div className="top-status"><span className="pulse-dot"/> SYSTEM OPERATIONAL</div></header><div className="role-center"><BiometricFlow onVerified={()=>setStage("fingerprint")}/></div></main>;
  if(stage==="fingerprint") return <main className="auth-page"><header className="topbar"><div className="brand">◈ FINORA</div></header><div className="role-center"><div className="biometric-card"><div className="eyebrow red">● BIOMETRIC AUTHENTICATION</div><h1>Fingerprint</h1><p className="center-copy">Demo hardware layer. Fingerprint is intentionally not part of normal Project Lead login; this screen demonstrates the sensitive-operation biometric hook.</p><div className="fingerprint">◎</div><button className="primary-button wide" onClick={()=>router.push("/lead")}>Simulate Hardware Touch →</button><button className="ghost-button wide" onClick={()=>router.push("/")}>Cancel & Lock Session</button></div></div></main>;
  return <main className="auth-page"><header className="topbar"><div className="brand">◈ FINORA</div><div className="top-status"><span className="pulse-dot"/> SYSTEM OPERATIONAL</div></header><div className="role-center"><div className="login-card wide-card"><div className="eyebrow green">● SECURE CREDENTIAL GATEWAY</div><h1>Project Lead Access</h1><label>WORK EMAIL<input defaultValue="lead@finora.demo"/></label><label>PASSWORD<input type="password" defaultValue="FinoraDemo"/></label><button className="primary-button wide" onClick={()=>setStage("biometric")}>Continue to Biometric Verification →</button><a className="back-link" href="/">← Return to Role Selection</a></div></div></main>;
}
