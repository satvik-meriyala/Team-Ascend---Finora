"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const [email,setEmail]=useState(roleEmail());
  const [password,setPassword]=useState("FinoraDemo");
  const [trust,setTrust]=useState(false);
  function roleEmail() {
    return "nishka@finora.demo";
  }
  return <main className="auth-page">
    <header className="topbar"><div className="brand"><span className="brand-mark">◈</span><span>FINORA</span></div><div className="top-status"><span className="pulse-dot"/> SYSTEM OPERATIONAL</div></header>
    <div className="role-center">
      <div className="login-card wide-card">
        <div className="eyebrow green">● SECURE CREDENTIAL GATEWAY</div>
        <h1>Enter Your Credentials</h1>
        <p className="subtle center-copy">Employee workspace</p>
        <label>WORK EMAIL<input value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@company.com"/></label>
        <label>PASSWORD<div className="password-wrap"><input type="password" value={password} onChange={e=>setPassword(e.target.value)}/><span>◉</span></div></label>
        <label className="checkline"><input type="checkbox" checked={trust} onChange={e=>setTrust(e.target.checked)}/> Trust this device (30 days)</label>
        <button className="primary-button wide" onClick={()=>router.push("/employee")}>Continue to Workspace →</button>
        <a className="back-link" href="/">← Return to Role Selection</a>
      </div>
    </div>
    <footer className="footer">◈ End-to-End Encrypted • Demo access • Strict access governance enforced</footer>
  </main>;
}
