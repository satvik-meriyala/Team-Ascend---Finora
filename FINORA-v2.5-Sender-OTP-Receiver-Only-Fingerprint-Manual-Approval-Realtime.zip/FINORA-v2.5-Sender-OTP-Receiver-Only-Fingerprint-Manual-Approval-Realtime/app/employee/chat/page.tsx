"use client";
import {useEffect,useState} from "react";
import ChatWindow from "../../components/ChatWindow"; import {AppNav,Header,PageFooter} from "../../components/FinoraShell";
export default function EmployeeChat(){
 const [user,setUser]=useState("emp-1");
 useEffect(()=>{const q=new URLSearchParams(window.location.search).get("user");if(q==="emp-1"||q==="emp-2")setUser(q)},[]);
 return <div className="app-page"><Header role={`EMPLOYEE • SECURE CHAT • ${user==="emp-2"?"ARJUN":"NISHKA"}`}/><AppNav role="employee"/><main className="chat-page"><ChatWindow currentUserId={user} initialOtherUserId={user==="emp-2"?"emp-1":"lead-1"} role="employee"/></main><PageFooter/></div>
}
