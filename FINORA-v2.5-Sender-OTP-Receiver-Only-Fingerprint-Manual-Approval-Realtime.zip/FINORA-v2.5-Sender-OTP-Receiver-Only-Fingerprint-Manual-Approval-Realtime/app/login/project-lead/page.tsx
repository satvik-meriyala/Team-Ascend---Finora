"use client";
import {useState} from "react";
import {useRouter} from "next/navigation";
import LeadAuth from "../../components/LeadAuth";
export default function Login(){
 const [auth,setAuth]=useState(false);const router=useRouter();
 if(auth)return <main className="auth-page"><header className="topbar"><div className="brand">◈ FINORA</div></header><div className="role-center"><div className="login-card wide-card"><div className="eyebrow green">● SECURE CREDENTIAL GATEWAY</div><h1>Project Lead Credentials</h1><label>WORK EMAIL<input defaultValue="lead@finora.demo"/></label><label>PASSWORD<input type="password" defaultValue="FinoraDemo"/></label><button className="primary-button wide" onClick={()=>router.push("/lead")}>Continue to Biometric Verification →</button><a className="back-link" href="/">← Return to Role Selection</a></div></div></main>;
 return <LeadAuth onVerified={()=>setAuth(true)}/>;
}