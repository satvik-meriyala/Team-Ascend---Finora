import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "FINORA",
  description: "Secure communication and deepfake-prevention demonstration platform"
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}