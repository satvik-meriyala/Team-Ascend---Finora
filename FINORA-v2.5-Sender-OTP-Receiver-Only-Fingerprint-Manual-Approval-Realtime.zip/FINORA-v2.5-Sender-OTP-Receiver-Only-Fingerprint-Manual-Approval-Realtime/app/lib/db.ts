export type Role = "employee" | "project-lead" | "cfo";
export type RequestKind = "transaction" | "file";
export type RequestStatus = "normal" | "awaiting-otp" | "awaiting-receiver-fingerprint" | "pending" | "approved" | "denied";

export type User = { id:string; name:string; role:Role; department:string; online:boolean; leadId?:string };
export type Message = { id:string; from:string; to:string; text:string; createdAt:number; secure:boolean };
export type SecurityRequest = {
  id:string; kind:RequestKind; senderId:string; receiverId:string; leadId:string;
  title:string; amount?:number; fileName?:string;
  sensitivity:"low"|"medium"|"high"|"critical"; risk:number; status:RequestStatus;
  otp?:string; otpVerified?:boolean; fingerprintVerified?:boolean; leadReason?:string; createdAt:number;
};
export type SecurityEvent = { id:string; text:string; level:"info"|"success"|"warning"|"critical"; createdAt:number };
export type FinoraState = {
  employeeDataset:{contacts:string[]; requestIds:string[]};
  leadDataset:{leadId:string; teamIds:string[]; queueIds:string[]};
  cfoDataset:{leadIds:string[]; observedRequestIds:string[]};
  users:User[]; messages:Message[]; requests:SecurityRequest[]; events:SecurityEvent[];
};

export const STORAGE_KEY="finora-role-aware-state-v25";
export const CHANNEL_NAME="finora-role-aware-sync-v25";

export const employeeDataset = {
  contacts:["lead-1","lead-2","emp-2","cfo-1"],
  pinned:["lead-1","lead-2"],
  recent:["cfo-1","emp-2"]
};
export const projectLeadDataset = {
  leadId:"lead-1",
  teamIds:["emp-1","emp-2"],
  queueIds:["req-demo"]
};
export const cfoDataset = {
  leadIds:["lead-1","lead-2"],
  observedRequestIds:["req-demo"]
};

export const seedState:FinoraState = {
  employeeDataset:{contacts:employeeDataset.contacts,requestIds:["req-demo"]},
  leadDataset:{leadId:projectLeadDataset.leadId,teamIds:projectLeadDataset.teamIds,queueIds:projectLeadDataset.queueIds},
  cfoDataset:{leadIds:cfoDataset.leadIds,observedRequestIds:cfoDataset.observedRequestIds},
  users:[
    {id:"emp-1",name:"Nishka",role:"employee",department:"Operations",online:true,leadId:"lead-1"},
    {id:"emp-2",name:"Arjun",role:"employee",department:"Finance",online:true,leadId:"lead-2"},
    {id:"lead-1",name:"Project Lead A",role:"project-lead",department:"Project Core Mesh",online:true},
    {id:"lead-2",name:"Project Lead B",role:"project-lead",department:"Secure Infrastructure",online:true},
    {id:"cfo-1",name:"CFO",role:"cfo",department:"Executive",online:true}
  ],
  messages:[
    {id:"m1",from:"lead-1",to:"emp-1",text:"Please review the updated payment request. I will verify any high-risk action here.",createdAt:Date.now()-1080000,secure:false},
    {id:"m2",from:"emp-1",to:"lead-1",text:"Received. I will send the invoice through the secure channel.",createdAt:Date.now()-960000,secure:false},
    {id:"m3",from:"cfo-1",to:"lead-1",text:"Keep the approval rationale attached to every sensitive decision.",createdAt:Date.now()-720000,secure:true},
    {id:"m4",from:"lead-2",to:"emp-1",text:"Project Core Mesh checkpoint moved to 3:00 PM.",createdAt:Date.now()-540000,secure:false}
  ],
  requests:[
    {id:"req-demo",kind:"transaction",senderId:"emp-1",receiverId:"emp-2",leadId:"lead-2",title:"Invoice Settlement — ABC Solutions",amount:50000,sensitivity:"high",risk:72,status:"pending",otpVerified:true,fingerprintVerified:true,createdAt:Date.now()-300000},
    {id:"req-approved",kind:"file",senderId:"emp-1",receiverId:"emp-2",leadId:"lead-2",title:"Quarterly Audit Pack",fileName:"Q3_Audit_Pack.pdf",sensitivity:"high",risk:69,status:"approved",otpVerified:true,fingerprintVerified:true,leadReason:"Hash matched the registered audit record.",createdAt:Date.now()-7200000},
    {id:"req-denied",kind:"transaction",senderId:"emp-1",receiverId:"emp-2",leadId:"lead-2",title:"Vendor Settlement — Unknown Account",amount:80000,sensitivity:"critical",risk:93,status:"denied",otpVerified:true,fingerprintVerified:true,leadReason:"Recipient account did not match the registered vendor.",createdAt:Date.now()-10800000}
  ],
  events:[
    {id:"e1",text:"Employee role dataset loaded",level:"success",createdAt:Date.now()-900000},
    {id:"e2",text:"Project Lead governance dataset loaded",level:"info",createdAt:Date.now()-840000},
    {id:"e3",text:"CFO executive observation dataset loaded",level:"info",createdAt:Date.now()-780000}
  ]
};

export function loadState():FinoraState{
  if(typeof window==="undefined") return seedState;
  try{
    const raw=localStorage.getItem(STORAGE_KEY);
    if(!raw){
      const fresh=structuredClone(seedState);
      localStorage.setItem(STORAGE_KEY,JSON.stringify(fresh));
      return fresh;
    }
    return JSON.parse(raw) as FinoraState;
  }catch{
    return structuredClone(seedState);
  }
}

export function saveState(state:FinoraState){
  const serialized=JSON.stringify(state);
  localStorage.setItem(STORAGE_KEY,serialized);
  // BroadcastChannel gives immediate cross-tab delivery. The storage event and
  // the custom event below provide fallbacks for browsers that throttle one of them.
  try{
    const c=new BroadcastChannel(CHANNEL_NAME);
    c.postMessage({type:"state",state});
    c.close();
  }catch{}
  try{window.dispatchEvent(new CustomEvent("finora-state-changed",{detail:state}));}catch{}
}

export function resetState(){
  const fresh=structuredClone(seedState);
  saveState(fresh);
}

export function getUser(state:FinoraState,id:string){return state.users.find(u=>u.id===id);}
export function assignedLeadId(state:FinoraState,receiverId:string){
  return getUser(state,receiverId)?.leadId || "lead-1";
}
export function riskScore(kind:RequestKind,amount:number,fileName:string){
  let score=kind==="transaction"?30:24;
  if(amount>=10000)score+=22;if(amount>=50000)score+=18;
  if(/confidential|secret|contract|payroll|credential|ledger|audit/i.test(fileName))score+=22;
  return Math.min(98,score+Math.floor(Math.random()*7));
}
export function sensitivityFromRisk(r:number):SecurityRequest["sensitivity"]{
  return r>=85?"critical":r>=65?"high":r>=40?"medium":"low";
}
export function needsVerification(r:Pick<SecurityRequest,"sensitivity"|"amount">){
  return r.sensitivity==="high"||r.sensitivity==="critical"||(r.amount??0)>=25000;
}
