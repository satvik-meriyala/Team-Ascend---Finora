"use client";

import {useEffect,useRef,useState} from "react";
import {FaceLandmarker,FilesetResolver} from "@mediapipe/tasks-vision";

type Stage="face"|"blink"|"done";
type Detector="none"|"tasks"|"mesh";

const TASK_MODEL="https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
const TASK_WASM="https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22/wasm";
const MESH_SOURCES=[
  "https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js",
  "https://unpkg.com/@mediapipe/face_mesh/face_mesh.js"
];
const MESH_BASE="https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/";

function eyeAspectRatio(points:any[],ids:number[]){
  const p=(i:number)=>points[ids[i]];
  const d=(a:any,b:any)=>Math.hypot(a.x-b.x,a.y-b.y);
  const vertical=(d(p(1),p(5))+d(p(2),p(4)))/2;
  const horizontal=d(p(0),p(3));
  return horizontal?vertical/horizontal:0;
}

function averageEyeRatio(landmarks:any[]){
  // MediaPipe Face Mesh eye landmarks.
  const left=eyeAspectRatio(landmarks,[33,160,158,133,153,144]);
  const right=eyeAspectRatio(landmarks,[362,385,387,263,373,380]);
  return (left+right)/2;
}

function blinkBlendshape(categories:any[]|undefined){
  if(!categories?.length)return 0;
  const l=categories.find(c=>c.categoryName==="eyeBlinkLeft")?.score||0;
  const r=categories.find(c=>c.categoryName==="eyeBlinkRight")?.score||0;
  return (l+r)/2;
}

function loadScript(src:string){
  return new Promise<void>((resolve,reject)=>{
    const existing=document.querySelector(`script[data-finora-face-mesh="${src}"]`) as HTMLScriptElement|null;
    if(existing){
      if((window as any).FaceMesh)return resolve();
      existing.addEventListener("load",()=>resolve(),{once:true});
      existing.addEventListener("error",()=>reject(new Error("Face Mesh script failed")),{once:true});
      return;
    }
    const script=document.createElement("script");
    script.src=src;script.async=true;script.dataset.finoraFaceMesh=src;
    script.onload=()=>resolve();script.onerror=()=>reject(new Error("Face Mesh script failed"));
    document.head.appendChild(script);
  });
}

export default function LeadAuth({onVerified}:{onVerified:()=>void}){
 const [stage,setStage]=useState<Stage>("face");
 const [detector,setDetector]=useState<Detector>("none");
 const [cameraReady,setCameraReady]=useState(false);
 const [faceSeen,setFaceSeen]=useState(false);
 const [blinkCount,setBlinkCount]=useState(0);
 const [targetBlinks,setTargetBlinks]=useState(3);
 const [status,setStatus]=useState("Starting camera…");
 const [error,setError]=useState("");
 const videoRef=useRef<HTMLVideoElement>(null);
 const streamRef=useRef<MediaStream|null>(null);
 const landmarkerRef=useRef<FaceLandmarker|null>(null);
 const meshRef=useRef<any>(null);
 const runningRef=useRef(false);
 const rafRef=useRef<number|null>(null);
 const countRef=useRef(0);
 const closedRef=useRef(false);
 const closedAtRef=useRef(0);
 const lastBlinkRef=useRef(0);
 const lastVideoTimeRef=useRef(-1);
 const processingRef=useRef(false);

 useEffect(()=>{const t=setTimeout(()=>setStage("blink"),600);return()=>clearTimeout(t)},[]);
 useEffect(()=>()=>stopCamera(),[]);

 function stopCamera(){
   runningRef.current=false;
   processingRef.current=false;
   if(rafRef.current)cancelAnimationFrame(rafRef.current);
   rafRef.current=null;
   try{landmarkerRef.current?.close()}catch{}
   landmarkerRef.current=null;
   try{meshRef.current?.close()}catch{}
   meshRef.current=null;
   streamRef.current?.getTracks().forEach(t=>t.stop());
   streamRef.current=null;
   if(videoRef.current)videoRef.current.srcObject=null;
 }

 function registerBlink(score:number){
   const now=performance.now();
   const CLOSED=0.19;
   const OPEN=0.235;
   const MIN_CLOSED=55;
   const COOLDOWN=500;
   if(!closedRef.current&&score<=CLOSED){
     closedRef.current=true;closedAtRef.current=now;setStatus("Eyes closed");return;
   }
   if(closedRef.current&&score>=OPEN&&now-closedAtRef.current>=MIN_CLOSED&&now-lastBlinkRef.current>=COOLDOWN){
     closedRef.current=false;lastBlinkRef.current=now;
     countRef.current+=1;setBlinkCount(countRef.current);setStatus(countRef.current>=targetBlinks?"Blink verification complete":"Blink detected");
     if(countRef.current>=targetBlinks){runningRef.current=false;setTimeout(()=>{stopCamera();setStage("done")},250);}
   }
 }

 async function startFaceMesh(){
   let lastError:any=null;
   for(const src of MESH_SOURCES){
     try{
       await loadScript(src);
       const FaceMesh=(window as any).FaceMesh;
       if(!FaceMesh)throw new Error("FaceMesh global unavailable");
       const mesh=new FaceMesh({locateFile:(file:string)=>MESH_BASE+file});
       mesh.setOptions({maxNumFaces:1,refineLandmarks:true,minDetectionConfidence:.55,minTrackingConfidence:.55});
       mesh.onResults((result:any)=>{
         if(!runningRef.current)return;
         const landmarks=result.multiFaceLandmarks?.[0];
         setFaceSeen(!!landmarks);
         if(landmarks)registerBlink(averageEyeRatio(landmarks));
       });
       meshRef.current=mesh;
       setDetector("mesh");
       setStatus("Look at the camera and blink naturally");
       return true;
     }catch(e){lastError=e;}
   }
   if(lastError)throw lastError;
   return false;
 }

 async function startCamera(){
   stopCamera();
   setError("");setCameraReady(false);setFaceSeen(false);setDetector("none");
   setBlinkCount(0);countRef.current=0;closedRef.current=false;closedAtRef.current=0;lastBlinkRef.current=0;lastVideoTimeRef.current=-1;
   setStatus("Starting camera…");setTargetBlinks(3);
   try{
     if(!navigator.mediaDevices?.getUserMedia)throw new Error("Camera access is not available in this browser.");
     const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:{ideal:1280},height:{ideal:720}},audio:false});
     streamRef.current=stream;
     const video=videoRef.current;if(!video)throw new Error("Camera preview is unavailable.");
     video.srcObject=stream;video.muted=true;video.playsInline=true;
     await new Promise<void>((resolve,reject)=>{
       if(video.readyState>=1)return resolve();
       const onMeta=()=>{video.removeEventListener("loadedmetadata",onMeta);resolve()};
       video.addEventListener("loadedmetadata",onMeta,{once:true});
       setTimeout(()=>reject(new Error("Camera preview did not start.")),7000);
     });
     await video.play();setCameraReady(true);setStatus("Loading blink detector…");

     // Primary detector: MediaPipe Tasks.
     try{
       const vision=await FilesetResolver.forVisionTasks(TASK_WASM);
       const lm=await FaceLandmarker.createFromOptions(vision,{baseOptions:{modelAssetPath:TASK_MODEL},runningMode:"VIDEO",numFaces:1,minFaceDetectionConfidence:.55,minFacePresenceConfidence:.55,minTrackingConfidence:.55,outputFaceBlendshapes:true});
       landmarkerRef.current=lm;setDetector("tasks");setStatus("Look at the camera and blink naturally");
     }catch{
       // Reliable fallback: classic MediaPipe Face Mesh. This avoids leaving the
       // camera running with a dead AI status when the Tasks model is unavailable.
       try{await startFaceMesh();}
       catch{throw new Error("Blink detector could not be loaded. Check that this browser can reach the MediaPipe CDN, then press Retry.");}
     }

     runningRef.current=true;
     const tick=async()=>{
       if(!runningRef.current)return;
       const v=videoRef.current;
       try{
         if(landmarkerRef.current&&v&&v.readyState>=2&&v.currentTime!==lastVideoTimeRef.current){
           lastVideoTimeRef.current=v.currentTime;
           const result=landmarkerRef.current.detectForVideo(v,performance.now());
           const landmarks=result.faceLandmarks?.[0];
           setFaceSeen(!!landmarks);
           if(landmarks)registerBlink(blinkBlendshape(result.faceBlendshapes?.[0]?.categories));
         }else if(meshRef.current&&v&&v.readyState>=2&&!processingRef.current){
           processingRef.current=true;
           await meshRef.current.send({image:v});
           processingRef.current=false;
         }
       }catch{processingRef.current=false;}
       rafRef.current=requestAnimationFrame(()=>void tick());
     };
     void tick();
   }catch(e:any){
     setCameraReady(false);setError(e?.message||"Camera or blink detector unavailable.");setStatus("Camera unavailable");stopCamera();
   }
 }

 useEffect(()=>{if(stage!=="blink")return;void startCamera();return()=>stopCamera()},[stage]);
 const bypass=()=>{stopCamera();setStage("done")};
 const reset=()=>{setStage("blink")};

 return <main className="auth-page"><header className="topbar"><div className="brand"><span className="brand-mark">◈</span> FINORA</div><div className="top-status"><span className="pulse-dot"/> SYSTEM OPERATIONAL</div></header>
  <div className="role-center"><div className="biometric-card lead-auth-card">
   {stage==="face"&&<><h1>Facial Recognition</h1><p className="center-copy">Position your face inside the frame. Facial identity matching is simulated for this demonstration.</p><div className="camera-box"><div className="face-reticle">◎</div><div className="camera-status">FACE MATCH CONFIRMED</div></div><div className="success-box">✓ Facial identity confirmed</div></>}
   {stage==="blink"&&<><h1>Blink Verification</h1><p className="center-copy">Look at the camera and blink naturally three times.</p>
    <div className="blink-camera"><video ref={videoRef} muted playsInline autoPlay/><div className="blink-reticle"><i/></div>{cameraReady&&!faceSeen&&<div className="camera-center-hint">Face the camera</div>}</div>
    <div className="blink-simple-status"><span>BLINKS</span><strong>{blinkCount} / {targetBlinks}</strong><em>{status}</em></div>
    {error&&<div className="warning-box">{error}</div>}
    <div className="auth-actions"><button className="ghost-button" onClick={()=>void startCamera()}>↻ Retry</button><button className="ghost-button" onClick={bypass}>Bypass</button></div>
    <p className="auth-note">Camera video is processed in the browser and is not stored.</p>
   </>}
   {stage==="done"&&<><h1>Authentication Passed</h1><div className="success-box">✓ Face identity confirmed<br/>✓ Blink verification completed or bypassed<br/>✓ Project Lead session ready</div><button className="primary-button wide" onClick={onVerified}>Enter Project Lead Workspace →</button></>}
  </div></div><footer className="footer">◈ FINORA • Camera-based blink verification • No biometric data is stored</footer></main>;
}
