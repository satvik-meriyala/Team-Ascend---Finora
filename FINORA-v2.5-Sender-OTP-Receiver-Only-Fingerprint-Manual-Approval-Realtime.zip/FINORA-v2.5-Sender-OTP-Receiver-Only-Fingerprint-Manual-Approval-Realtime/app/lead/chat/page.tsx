"use client";
import {useEffect,useState} from "react";
import ChatWindow from "../../components/ChatWindow"; import {AppNav,Header,PageFooter} from "../../components/FinoraShell";
export default function LeadChat(){
 const [user,setUser]=useState("lead-1");
 useEffect(()=>{const q=new URLSearchParams(window.location.search).get("user");if(q==="lead-1"||q==="lead-2")setUser(q)},[]);
 return <div className="app-page"><Header role={`PROJECT LEAD • SECURE CHAT • ${user==="lead-2"?"LEAD B":"LEAD A"}`}/><AppNav role="project-lead"/><main className="chat-page"><ChatWindow currentUserId={user} initialOtherUserId={user==="lead-2"?"emp-2":"emp-1"} role="project-lead"/></main><PageFooter/></div>
}
