"use client";
import {useMemo,useState} from "react";
import {AppNav,Header,PageFooter,ResetDemoButton,Stat,useFinoraState} from "../components/FinoraShell";
import {getUser} from "../lib/db";

export default function Lead(){
 const {state,commit}=useFinoraState();
 const [activeLead,setActiveLead]=useState("lead-1");
 const [tab,setTab]=useState<"pending"|"approved"|"denied">("pending");
 const [reason,setReason]=useState("");
 const [selected,setSelected]=useState<string|null>(null);
 const leadUser=getUser(state,activeLead);
 const incomingOtp=useMemo(()=>state.requests.filter(r=>r.receiverId===activeLead&&r.status==="awaiting-otp").sort((a,b)=>b.createdAt-a.createdAt),[state.requests,activeLead]);
 const queue=state.requests.filter(r=>r.leadId===activeLead&&(tab==="pending"?(r.status==="pending"):r.status===tab)).sort((a,b)=>b.createdAt-a.createdAt);
 const decide=(id:string,status:"approved"|"denied")=>{
   if(!reason.trim()){alert("Enter the approval/denial reason.");return;}
   const decisionReason=reason.trim();
   commit(current=>({...current,requests:current.requests.map(r=>r.id===id?{...r,status,leadReason:decisionReason}:r),events:[...current.events,{id:crypto.randomUUID(),text:`${leadUser?.name} ${status}: ${decisionReason}`,level:status==="approved"?"success":"warning",createdAt:Date.now()}]}));
   setReason("");setSelected(null);
 };
 return <div className="app-page"><Header role={`PROJECT LEAD WORKSPACE • ${leadUser?.name||"Project Lead"}`}/><AppNav role="project-lead"/><main className="dashboard-page">
  <div className="page-heading"><div><div className="eyebrow green left">PROJECT LEAD GOVERNANCE</div><h1>{leadUser?.name} Approval Command Centre</h1><p>Live simulation: incoming OTP notifications appear here when this Project Lead is the receiver. After sender OTP verification and receiver fingerprint verification, the request enters this Lead's approval queue.</p></div><a className="primary-button nav-cta" href={`/lead/chat?user=${activeLead}`}>Open Secure Chat →</a></div>

  <section className="simulation-strip"><div><div className="section-title">APPROVER / RECEIVER IDENTITY</div><b>Simulate Project Lead:</b><span className="subtle"> Switching Lead changes both the private OTP inbox and the approval queue.</span></div><div className="identity-switch">{state.users.filter(u=>u.role==="project-lead").map(u=><button key={u.id} className={activeLead===u.id?"active":""} onClick={()=>{setActiveLead(u.id);setTab("pending");setSelected(null);setReason("")}}>{u.name}<small>{u.department}</small></button>)}</div></section>

  <div className="stat-row four"><Stat label="OTP Waiting" value={incomingOtp.length} tone="warning"/><Stat label="Pending Approval" value={state.requests.filter(r=>r.leadId===activeLead&&(r.status==="pending")).length} tone="warning"/><Stat label="Approved" value={state.requests.filter(r=>r.leadId===activeLead&&r.status==="approved").length} tone="green"/><Stat label="Denied" value={state.requests.filter(r=>r.leadId===activeLead&&r.status==="denied").length} tone="red"/></div>

  <section className="wide-panel receiver-panel"><div className="section-title">PRIVATE OTP INBOX • {leadUser?.name?.toUpperCase()}</div>
   {incomingOtp.map(r=>{const sender=getUser(state,r.senderId);return <div className="otp-card" key={r.id}><div className="otp-card-main"><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><span>OTP REQUIRED</span></div><h3>{r.title}</h3><p>From <b>{sender?.name}</b> → <b>{leadUser?.name}</b> • {r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p><small>You are the receiver for this request. After verification, it will enter your approval queue.</small></div><div className="otp-entry"><div className="otp-notification"><span>🔐 RECEIVER OTP</span><strong>{r.otp}</strong><small>This OTP is visible only to the receiver. Share it with the sender through the external medium; the sender enters it in their own verification field.</small></div></div></div>})}
   {!incomingOtp.length&&<div className="empty-state">No OTP is waiting for {leadUser?.name}. If an employee sends a protected request to this Lead, it will appear here immediately.</div>}
  </section>

  <section className="wide-panel"><div className="section-title">GOVERNANCE QUEUE • {leadUser?.name?.toUpperCase()}</div><div className="tabs">{(["pending","approved","denied"] as const).map(t=><button key={t} className={tab===t?"active":""} onClick={()=>setTab(t)}>{t.toUpperCase()}</button>)}</div><div className="request-grid">{queue.map(r=>{const sender=getUser(state,r.senderId);const receiver=getUser(state,r.receiverId);return <div className="approval-card" key={r.id}><div className="request-card-head"><span className={`severity ${r.sensitivity}`}>{r.sensitivity}</span><b>{r.risk}% AI RISK</b></div><h3>{r.title}</h3><p>{r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName}</p><div className="routing-line">From <b>{sender?.name}</b> → <b>{receiver?.name}</b> • OTP {r.otpVerified?"VERIFIED":"NOT VERIFIED"}</div>{r.fingerprintVerified&&<div className="fingerprint-mini">✓ Authorization layer verified</div>}{tab==="pending"&&r.status==="pending"&&<><textarea value={selected===r.id?reason:""} onChange={e=>{setSelected(r.id);setReason(e.target.value)}} placeholder="Why are you approving or denying this?"/><div className="two-buttons"><button className="approve" onClick={()=>decide(r.id,"approved")}>✓ Approve</button><button className="deny" onClick={()=>decide(r.id,"denied")}>✕ Deny</button></div></>}{tab!=="pending"&&r.leadReason&&<div className={tab==="approved"?"success-box":"danger-box"}>{tab==="approved"?"✓ APPROVED":"✕ DENIED"}<br/><span>Why: {r.leadReason}</span></div>}</div>})}{!queue.length&&<div className="empty-state">No items in {leadUser?.name}'s {tab} queue.</div>}</div></section>

  <div className="simulation-flow"><span>Sender sends</span><b>→</b><span>Receiver gets private OTP</span><b>→</b><span>Receiver fingerprint</span><b>→</b><span>{leadUser?.name} approves/denies</span><b>→</b><span>Sender sees reason</span></div>
  <div className="workspace-note"><b>Routing rule:</b> every employee has an assigned Project Lead. If the receiver is itself a Project Lead, that Lead is both the receiver and approver for the simulation.</div><ResetDemoButton/>
 </main><PageFooter/></div>;
}
