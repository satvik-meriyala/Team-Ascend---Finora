import Link from "next/link";
export default function Home(){
 const roles=[
  {href:"/login/employee",name:"Employee",desc:"Secure messaging, files and transactions",icon:"▣"},
  {href:"/login/project-lead",name:"Project Lead",desc:"Biometric access and approval governance",icon:"✥"},
  {href:"/login/cfo",name:"CFO",desc:"Executive oversight and project-lead activity",icon:"₿"}
 ];
 return <main className="auth-page"><header className="topbar"><div className="brand"><span className="brand-mark">◈</span> FINORA</div><div className="top-status"><span className="pulse-dot"/> SYSTEM OPERATIONAL</div></header><div className="role-center"><div className="login-card"><div className="eyebrow green">● LOGIN</div><h1>Select Your Role</h1><p className="subtle center-copy">Choose the security workspace for this demonstration.</p><div className="role-list">{roles.map(r=><Link className="role-option" href={r.href} key={r.name}><span className="role-icon">{r.icon}</span><span><strong>{r.name}</strong><small>{r.desc}</small></span><span className="arrow">→</span></Link>)}</div></div></div><footer className="footer">◈ End-to-End Encrypted • Strict access governance enforced</footer></main>;
}