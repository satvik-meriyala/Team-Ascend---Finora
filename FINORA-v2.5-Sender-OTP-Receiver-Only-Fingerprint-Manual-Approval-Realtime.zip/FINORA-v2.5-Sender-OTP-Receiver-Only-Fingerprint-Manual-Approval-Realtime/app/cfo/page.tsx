"use client";
import {useState} from "react";
import {AppNav,Header,PageFooter,ResetDemoButton,Stat,useFinoraState} from "../components/FinoraShell";
import {getUser} from "../lib/db";
export default function CFO(){
 const {state}=useFinoraState();const [lead,setLead]=useState("lead-1");
 const activity=state.requests.filter(r=>r.leadId===lead).sort((a,b)=>b.createdAt-a.createdAt);const leadUser=getUser(state,lead);
 return <div className="app-page"><Header role="CFO COMMAND CENTRE"/><AppNav role="cfo"/><main className="dashboard-page">
  <div className="page-heading"><div><div className="eyebrow green left">EXECUTIVE OVERSIGHT</div><h1>{leadUser?.name} Activity</h1><p>Observe Project Lead decisions. The Iris Scan remains an executive security feature and was bypassed at login for this laptop demo.</p></div><a className="primary-button nav-cta" href="/cfo/chat">Open Secure Chat →</a></div>
  <div className="stat-row four"><Stat label="Total actions" value={activity.length}/><Stat label="Approved" value={activity.filter(r=>r.status==="approved").length} tone="green"/><Stat label="Denied" value={activity.filter(r=>r.status==="denied").length} tone="red"/><Stat label="Pending" value={activity.filter(r=>r.status==="pending").length} tone="warning"/></div>
  <section className="wide-panel"><div className="section-title">PROJECT LEAD OBSERVATION DATASET</div><div className="lead-switch">{state.cfoDataset.leadIds.map(id=><button key={id} className={lead===id?"active":""} onClick={()=>setLead(id)}>{getUser(state,id)?.name||id}</button>)}</div><div className="activity-list">{activity.map(r=><div className="activity-row" key={r.id}><div className="activity-time">{new Date(r.createdAt).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</div><div className="activity-icon">{r.status==="approved"?"✓":r.status==="denied"?"✕":"…"}</div><div><strong>{r.status.toUpperCase()} — {r.title}</strong><p>{r.kind==="transaction"?`₹${r.amount?.toLocaleString("en-IN")}`:r.fileName} • AI risk {r.risk}%</p>{r.leadReason&&<small>Reason: {r.leadReason}</small>}</div></div>)}</div></section>
  <div className="iris-feature wide"><div className="eyebrow green left">BIOMETRIC FEATURE</div><b>◉ IRIS SCAN • EXECUTIVE VERIFICATION</b><p>Displayed as a real security capability. For this demonstration, the login flow uses an explicit Continue / Demo Bypass instead of requiring iris hardware.</p></div>
  <ResetDemoButton/>
 </main><PageFooter/></div>;
}