"use client";
import ChatWindow from "../../components/ChatWindow"; import {AppNav,Header,PageFooter} from "../../components/FinoraShell";
export default function CFOChat(){return <div className="app-page"><Header role="CFO • SECURE CHAT"/><AppNav role="cfo"/><main className="chat-page"><ChatWindow currentUserId="cfo-1" initialOtherUserId="lead-1" role="cfo"/></main><PageFooter/></div>}
