# FINORA v2.5 — Live OTP + Blink Simulation

This build fixes the two demonstration flows that need to update live across localhost tabs.

## Start

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Recommended live simulation

1. **Sender tab:** Employee → Secure Chat → choose a receiver → Send Approval.
2. **Receiver tab:** open `/employee/receiver` and select the receiver identity. If the receiver is a Project Lead, select that Project Lead.
3. The receiver sees the private OTP immediately and enters it. The sender never sees the OTP.
4. **Project Lead tab:** open `/lead`, select the assigned Project Lead. After OTP verification, the request appears in that Lead's Pending Approval queue immediately.
5. Enter an approval/denial reason and decide.
6. Return to the sender tab: the request changes to Approved/Denied and shows the reason.

The simulation uses localStorage, BroadcastChannel, a browser event, and a 400ms polling fallback so the three localhost tabs remain synchronized even when one browser mechanism is delayed.

## Project Lead blink verification

The blink screen has been simplified: no Morse, dot/dash, blink signal percentage, AI status panel, or protocol text. It uses the laptop camera and requires three natural blinks. The detector tries MediaPipe Face Landmarker first and automatically falls back to classic MediaPipe Face Mesh.

If your browser blocks the external MediaPipe assets, use Retry after allowing camera/network access. Bypass remains available only as the emergency demo fallback.
